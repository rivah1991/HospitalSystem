import { Component, computed, model } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { NgFor, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, NgIf, NgFor, FormsModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
     
})
// export class AppComponent {
//   title = 'tahiry-angular';
// }
export class AppComponent {
  isModalOpen = false;

  get filteredPatients() {
    return this.patients.filter(patient =>
      Object.values(patient)
        .join(' ')
        .toLowerCase()
        .includes(this.search.toLowerCase())
    );
  }

  search: string = '';

  patients = [
    {
      id: 'P001',
      name: 'Tahiry',
      age: 38,
      bloodGroup: 'O+',
      treatment: 'Traitement A',
      mobile: '034 12 345 67',
      email: 'patient1@email.com',
      address: 'Rue 123, Antananarivo'
    },
    {
      id: 'P002',
      name: 'Valerie',
      age: 30,
      bloodGroup: 'A-',
      treatment: 'Traitement B',
      mobile: '034 89 654 32',
      email: 'patient2@email.com',
      address: 'Rue 456, Tamatave'
    },
    {
      id: 'P003',
      name: 'Patient 3',
      age: 45,
      bloodGroup: 'B+',
      treatment: 'Traitement C',
      mobile: '034 76 543 21',
      email: 'patient3@email.com',
      address: 'Rue 789, Majunga'
    }
  ];
  

  openModal() {
    this.isModalOpen = true;
   
  }

  closeModal() {
    this.isModalOpen = false;
  }
  
}